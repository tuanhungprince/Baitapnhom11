$(document).ready(function(){
    $('.btn-order').click(function(){
        $('.modal').css('display', 'flex').show(1000);
    })
    $('.btn').click(function(){
        $('.modal').css('display', 'none');
    })
})