// // Lấy ra phần tử container và nút
// var container = document.getElementById("container");
// var myBtn = document.getElementById("myBtn");

// // Lắng nghe sự kiện cuộn
// window.addEventListener("scroll", function() {
//   var scrollPosition = window.scrollY; // Lấy vị trí cuộn của trang
  
//   // Tính toán vị trí top mới cho nút
//   var newTop = scrollPosition + window.innerHeight - myBtn.offsetHeight - 20; // 20 là khoảng cách từ nút đến bottom
  
//   // Đặt vị trí top mới cho nút
//   myBtn.style.top = newTop + "px";
// });
