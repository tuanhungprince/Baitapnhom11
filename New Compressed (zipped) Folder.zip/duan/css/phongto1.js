// Lấy ra phần tử .about_tacgia_khunganh
var khungAnh = document.querySelector(".about_tacgia_khunganh");
// Lắng nghe sự kiện khi chuột đi vào
khungAnh.addEventListener("mouseenter", function() {
    // Phóng to hình ảnh
    var img = this.querySelector(".about_tacgia_khunganh_img");
    img.style.transform = "scale(1.3)";
});

// Lắng nghe sự kiện khi chuột rời đi
khungAnh.addEventListener("mouseleave", function() {
    // Thu nhỏ hình ảnh
    var img = this.querySelector(".about_tacgia_khunganh_img");
    img.style.transform = "scale(1)";
});



// bbbbbbbbbb
// Lấy ra phần tử .about_tacgia_khunganh
var khungAnh = document.querySelector(".about_tacgia_khunganhb");
// Lắng nghe sự kiện khi chuột đi vào
khungAnh.addEventListener("mouseenter", function() {
    // Phóng to hình ảnh
    var img = this.querySelector(".about_tacgia_khunganh_imgb");
    img.style.transform = "scale(1.3)";
});

// Lắng nghe sự kiện khi chuột rời đi
khungAnh.addEventListener("mouseleave", function() {
    // Thu nhỏ hình ảnh
    var img = this.querySelector(".about_tacgia_khunganh_imgb");
    img.style.transform = "scale(1)";
});

// cccccccccccc
// Lấy ra phần tử .about_tacgia_khunganh
var khungAnh = document.querySelector(".about_tacgia_khunganhc");
// Lắng nghe sự kiện khi chuột đi vào
khungAnh.addEventListener("mouseenter", function() {
    // Phóng to hình ảnh
    var img = this.querySelector(".about_tacgia_khunganh_imgc");
    img.style.transform = "scale(1.3)";
});

// Lắng nghe sự kiện khi chuột rời đi
khungAnh.addEventListener("mouseleave", function() {
    // Thu nhỏ hình ảnh
    var img = this.querySelector(".about_tacgia_khunganh_imgc");
    img.style.transform = "scale(1)";
});
